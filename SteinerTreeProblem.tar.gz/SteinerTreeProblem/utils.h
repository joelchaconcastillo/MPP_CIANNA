int getRandomInteger0_N(int n);//get random integer [0, n]
double generateRandomDouble0_Max(double maxValue);
